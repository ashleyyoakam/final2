import CISC181.Week3.Package4.InsufficientFundsException;

public class TestAccountClass {
	
		   public static void main(String [] args)
		   {
		      Account c = new Account(702027278,2000,0.05);
		      System.out.println("Depositing $500...");
		      c.deposit(500.00);
		      System.out.println("New balance is",getBalance());
		      
		    }
}
